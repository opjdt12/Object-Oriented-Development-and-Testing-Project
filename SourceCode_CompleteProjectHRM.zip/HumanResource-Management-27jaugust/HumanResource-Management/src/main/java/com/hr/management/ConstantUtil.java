package com.hr.management;

public class ConstantUtil {

	public static final String DATABASE_CONNECTION = "jdbc:mysql://localhost:3306/hroperation";
	public static final String DATABASE_USERNAME = "root";
	public static final String DATABASE_PASSWORD = "Lily@0802Edina";
	//public static final String DATABASE_USERNAME = "test";
	//public static final String DATABASE_PASSWORD = "test@123";
}
