A Pen created at CodePen.io. You can find this one at http://codepen.io/mnafricano/pen/pusvG.

 A nice little sweet login form with a Chrome extension link at the bottom.